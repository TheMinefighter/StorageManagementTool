﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Win32;

namespace StorageManagementTool
{
    public partial class EditUserShellFolders : Form
    {
        private void USFOpenCurrentPath_btn_Click(object sender, EventArgs e)
        {
            if (CurrentUSFPath_tb.Text == "")
            {
                MessageBox.Show("Wählen sie einen UserShellFolder aus um dessen aktuellen Pfad öffnen zu können", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Wrapper.Executeexecuteable(Environment.ExpandEnvironmentVariables(@"%windir%\explorer.exe"), CurrentUSFPath_tb.Text, false, false, false);
            }
        }
        private void USFOpenNewPath_btn_Click(object sender, EventArgs e)
        {
            if (NewUSFPath_tb.Text == "")
            {
                MessageBox.Show("Wählen sie einen neuen Ort für den UserShellFolder um diesen öffnen zu können", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Wrapper.Executeexecuteable("explorer.exe", NewUSFPath_tb.Text, false, false, false);
            }
        }
        private void ExistingUSF_lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            EnableComponents();
            UserShellFolder currentUSF = UserShellFolder.AllEditableUserUserShellFolders[ExistingUSF_lb.SelectedIndex];
            Wrapper.GetRegValue(currentUSF.RegPaths[0], out object regValue);
            CurrentUSFPath_tb.Text = (string)regValue ?? "Fehler: Wert nicht vorhanden";
        }

        private void SetNewUSFPath_btn_Click(object sender, EventArgs e)
        {
            NewUSFPath_fbd.ShowDialog();
            NewUSFPath_tb.Text = NewUSFPath_fbd.SelectedPath;
        }
        public EditUserShellFolders()
        {

            InitializeComponent();
        }

        private void EditUserShellFolders_Load(object sender, EventArgs e)
        {
            EnableComponents();
            RefreshUSF();
        }

        private void RefreshUSF()
        {
            foreach (UserShellFolder usf in UserShellFolder.AllEditableUserUserShellFolders)
            {
                ExistingUSF_lb.Items.Add(usf.ViewedName);
            }
        }

        private void SetUSF_btn_Click(object sender, EventArgs e)
        {

            if (OperatingMethods.ChangeUserShellFolder(new DirectoryInfo(CurrentUSFPath_tb.Text), new DirectoryInfo(NewUSFPath_tb.Text),
                ExistingUSF_lb.SelectedIndex))
            {
                CurrentUSFPath_tb.Text = NewUSFPath_tb.Text;
            }
        }

        

        private void NewUSFPath_tb_TextChanged(object sender, EventArgs e)
        {
            EnableComponents();
        }

        private void CurrentUSFPath_tb_TextChanged(object sender, EventArgs e)
        {
            EnableComponents();
        }

        private void EnableComponents()
        {
            new[] { SetUSF_btn, USFOpenNewPath_btn }.ForEach(x => x.Enabled = NewUSFPath_tb.Text != "");
            USFOpenCurrentPath_btn.Enabled = CurrentUSFPath_tb.Text != "";
            SetNewUSFPath_btn.Enabled = ExistingUSF_lb.SelectedIndex != -1;
        }
    }
}
