﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.DirectoryServices.AccountManagement;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace StorageManagementTool
{
    /// <summary>
    ///     Contains system functionalities, which are not specific made for this project
    /// </summary>
    public static class Wrapper
    {
        private static readonly string[] ExecuteableExtensions = {".exe", ".pif", ".com", ".bat", ".cmd"};

        /// <summary>
        ///     Executes an executeable
        /// </summary>
        /// <param name="filename">The name of the File to execute</param>
        /// <param name="parameters">The parameters to use when satrting the file</param>
        /// <param name="admin">Whether the file should be executed with</param>
        /// <param name="hidden">Whether the Main Window of this executeable (if exists) should be shown</param>
        /// <param name="waitforexit">Whether the code should wait until the executeable exited</param>
        /// <returns>Whether the operation were successfull</returns>
        public static bool Executeexecuteable(string filename, string parameters, bool admin, bool hidden,
            bool waitforexit)
        {
            return Executeexecuteable(filename, parameters, out string[] tmp, out int _, waitforexit: waitforexit,
                hidden: hidden, admin: admin, asUser: false);
        }

        /// <summary>
        ///     Gives the WIN32APi Representation of an given RegistryValueKind
        /// </summary>
        /// <param name="kind"> The RegistryValueKind to represent</param>
        /// <returns>The WIN32API Representation of the given RegistryValueKind</returns>
        public static string Win32ApiRepresentation(this RegistryValueKind kind)
        {
            switch (kind)
            {
                case RegistryValueKind.String: return "REG_SZ";
                case RegistryValueKind.ExpandString: return "REG_EXPAND_SZ";
                case RegistryValueKind.Binary: return "REG_BINARY";
                case RegistryValueKind.DWord: return "REG_DWORD";
                case RegistryValueKind.MultiString: return "REG_MULTI_SZ";
                case RegistryValueKind.QWord: return "REG_QWORD";
                case RegistryValueKind.Unknown: return "REG_RESSOURCE_LIST";
                case RegistryValueKind.None: return "REG_NONE";
                default: throw new ArgumentOutOfRangeException(nameof(kind), kind, null);
            }
        }

        public static bool GetRegValue(RegPath path, out object toReturn, bool alt = false)
        {
            toReturn = null;
            if (alt)
            {
                if (!Executeexecuteable(Environment.ExpandEnvironmentVariables(@"%windir%\System32\reg.exe"),
                    " query \"" + path.RegistryKey + "\" /v \"" + path.ValueName + "\"", out string[] ret, out int _,
                    true, true, true, false, true))
                {
                    return false;
                }

                if (ret.Length == 2)
                {
                    toReturn = null;
                    return true;
                }

                char[] tmp = ret[2].ToCharArray();
                string toSwitch = new string(tmp).Substring(8 + path.ValueName.Length, 13);
                RegistryValueKind kind = Enum.GetValues(typeof(RegistryValueKind)).Cast<RegistryValueKind>()
                    .FirstOrDefault(x => toSwitch.Contains(x.Win32ApiRepresentation()));
                string data = new string(tmp.Skip(12 + path.ValueName.Length + kind.ToString().Length).ToArray());
                toReturn = data;
                switch (kind)
                {
                    case RegistryValueKind.DWord:
                        toReturn = uint.Parse(new string(data.Skip(2).ToArray()), NumberStyles.HexNumber);
                        break;
                    case RegistryValueKind.String:
                        toReturn = data;
                        break;
                    case RegistryValueKind.ExpandString: break;
                    case RegistryValueKind.Binary: break;
                    case RegistryValueKind.MultiString:
                        toReturn = data.Split('\0');
                        break;
                    case RegistryValueKind.QWord:
                        toReturn = ulong.Parse(new string(data.Skip(2).ToArray()), NumberStyles.HexNumber);
                        break;
                    case RegistryValueKind.Unknown:
                        toReturn = data;
                        break;
                    case RegistryValueKind.None: return false;
                }

                return true;
            }

            try
            {
                toReturn = Registry.GetValue(path.RegistryKey, path.ValueName, null);
            }
            catch (Exception)
            {
                return MessageBox.Show("Bei dem lesen des Registry Wertes " + path + " ist ein Fehler aufgetreten.",
                           "Fehler", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) == DialogResult.Retry &&
                       GetRegValue(path, out toReturn, alt);
            }

            return true;
        }

        /// <summary>
        ///     Executes an Executeable
        /// </summary>
        /// <param name="filename">The name of the file to execute</param>
        /// <param name="parameters">The parameters to use when satrting the file</param>
        /// <param name="returnData"> The String returned by the file</param>
        /// <param name="exitCode"> The exit code returned by the executable, only available if waitforexit=true</param>
        /// <param name="readReturnData">Whether to Read the output of the executeable started</param>
        /// <param name="waitforexit">Whether the code should wait until the executeable exited</param>
        /// <param name="hidden">Whether the main window of this executeable (if existing) should be hidden</param>
        /// <param name="admin">Whether the file should be executed with</param>
        /// <param name="asUser"></param>
        /// <returns>Whether the operation were successfull</returns>
        public static bool Executeexecuteable(string filename, string parameters, out string[] returnData,
            out int exitCode, bool readReturnData = false, bool waitforexit = false, bool hidden = false,
            bool admin = false, bool asUser = false)
        {
            exitCode = 0;
            returnData = null;
            if (!File.Exists(filename))
            {
                if (MessageBox.Show(
                        "Das Program \"" + filename +
                        "\" Konnte nicht ausgeführt werden, da dieses nicht unter dem erwarteten Pfad verfügbar war. Möchten sie den richtigen Pfad des Programms auswählen?",
                        "Fehler", MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.Yes)
                {
                    OpenFileDialog alternativeExecuteableSel = new OpenFileDialog
                    {
                        Filter = "Programme|*" + string.Join(";*", ExecuteableExtensions)
                    };
                    alternativeExecuteableSel.ShowDialog();
                    return Executeexecuteable(alternativeExecuteableSel.FileName, parameters, out returnData,
                        out exitCode, waitforexit: waitforexit, hidden: hidden, admin: admin, asUser: asUser);
                }
            }

            if (!ExecuteableExtensions.Contains(new FileInfo(filename).Extension))
            {
                if (new DialogResult[] {DialogResult.No, DialogResult.None}.Contains(MessageBox.Show(
                    "Es sollte das Program\"" + filename +
                    "\" ausgeführt werden, jedoch ist nicht bekannt das Dateien mit der Dateiendung " +
                    new FileInfo(filename).Extension +
                    " unter Windows ausführbar sind. Soll trotzdem versucht werden diese Datei auszuführen?", "Fehler",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Error)))
                {
                    return false;
                }
            }

            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                WindowStyle = hidden ? ProcessWindowStyle.Hidden : ProcessWindowStyle.Normal,
                FileName = filename,
                Arguments = parameters,
                RedirectStandardOutput = readReturnData
            };
            if (readReturnData && admin)
            {
                asUser = true;
            }

            startInfo.UseShellExecute = false;
            if (asUser)
            {
                if (!InsertCredentials.GetCredentials(admin, out InsertCredentials.Credentials tmp))
                {
                    return false;
                }

                startInfo.Password = tmp.Password;
                startInfo.UserName = tmp.Username;
            }
            else
            {
                if (admin)
                {
                    startInfo.Verb = "runas";
                    startInfo.UseShellExecute = true;
                }
            }

            process.StartInfo = startInfo;
            try
            {
                process.Start();
            }
            catch (Win32Exception)
            {
                DialogResult retry = MessageBox.Show(
                    "Fehler beim ausführen der Datei \" " + filename +
                    " \" hat der Nutzer hat dem Programm den Zugriff auf Administroteren Privilegien verwehrt, die für die Ausführung wahrscheinlich nötig gewesen wären. Soll das Programm den Vorgang abbrechen, den Vorgang wiederholen oder das Problem ignorieren und den Befehl ohne Adminstratorrechte ausführen",
                    "Fehler", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
                switch (retry)
                {
                    case DialogResult.Retry:
                        Executeexecuteable(filename, parameters, admin, hidden, waitforexit);
                        break;
                    case DialogResult.Ignore:
                        Executeexecuteable(filename, parameters, false, hidden, waitforexit);
                        break;
                    case DialogResult.Abort: return false;
                }
            }

            if (waitforexit)
            {
                process.WaitForExit();
                if (readReturnData)
                {
                    returnData = process.StandardOutput.FromStream();
                }

                exitCode = process.ExitCode;
                process.Dispose();
            }

            return true;
        }

        /// <summary>
        ///     Executes an Command using Windows Commandline
        /// </summary>
        /// <param name="cmd">The Command to Execute</param>
        /// <param name="admin">Whether the Command should be executed with</param>
        /// <param name="hidden">Whether to hide the Commandline </param>
        /// <param name="waitforexit">
        ///     Whether to wait until the command execution completed
        /// </param>
        /// <param name="debug">
        ///     Whether to run the command in debug mode
        /// </param>
        /// <returns>Whether the operation were successful</returns>
        public static bool ExecuteCommand(string cmd, bool admin, bool hidden, bool waitforexit = true,
            bool debug = false)
        {
            return ExecuteCommand(cmd, admin, hidden, out string[] tmp, waitforexit, debug);
        }

        /// <summary>
        ///     Executes an Command using Windows Commandline
        /// </summary>
        /// <param name="cmd">The Command to Execute</param>
        /// <param name="admin">Whether the Command should be executed with</param>
        /// <param name="hidden">Whether to hide the Commandline </param>
        /// <param name="returnData">The Data returned by the executeable</param>
        /// <param name="waitforexit">
        ///     Whether to wait until the command execution completed
        /// </param>
        /// <param name="debug">
        ///     Whether to run the command in debug mode
        /// </param>
        /// <param name="readReturnData">Whether to read the output of the Application</param>
        /// <returns>Whether the operation were successful</returns>
        /*  public static bool ExecuteCommand(string cmd, bool admin, bool hidden)
        {
           return ExecuteCommand(cmd, admin, hidden, true);
        }
        */
        //führt einen Windows-Consolen-Befehl aus
        public static bool ExecuteCommand(string cmd, bool admin, bool hidden, out string[] returnData,
            bool waitforexit = true, bool debug = false, bool readReturnData = false)
        {
            if (Executeexecuteable(Environment.ExpandEnvironmentVariables(@"%windir%\system32\cmd.exe"),
                (debug ? " /K " : " /C ") + cmd, out returnData, out int tmp, readReturnData, waitforexit, hidden,
                admin, false))
            {
                return tmp == 0;
            }

            return false;
        }

        #region From https://stackoverflow.com/a/3600342/6730162 access on 30.9.2017

        /// <summary>
        ///     Tests whether the program is being executed with Admin privileges
        /// </summary>
        /// <returns>Whether the Program is being executed with Admin privileges</returns>
        public static bool IsUserAdministrator()
        {
            try
            {
                return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion

        /// <summary>
        ///     Copies an Directory
        /// </summary>
        /// <param name="src">The Directory to copy from</param>
        /// <param name="target">The Directory, where the contents of src should be copied to</param>
        /// <returns>Whether the operation were successfull</returns>
        public static bool CopyFilesRecursively(DirectoryInfo src, DirectoryInfo target)
        {
            try
            {
                FileSystem.CopyDirectory(src.FullName, target.FullName, UIOption.AllDialogs);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Deletes an Folder
        /// </summary>
        /// <param name="toBeDeleted">The Folder to delete</param>
        /// <param name="deletePermanent">Whether the Folder should be deleted permanently</param>
        /// <returns>Whether the operation were sucessful</returns>
        public static bool DeleteDirectoryRecursivly(DirectoryInfo toBeDeleted, bool deletePermanent = true)
        {
            try
            {
                FileSystem.DeleteDirectory(toBeDeleted.FullName, UIOption.AllDialogs,
                    deletePermanent ? RecycleOption.DeletePermanently : RecycleOption.SendToRecycleBin);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Sets an Registry Value
        /// </summary>
        /// <param name="valueLocation">The Location of the Value to change</param>
        /// <param name="content">The content to write into the content</param>
        /// <param name="registryValueKind">The type of the content</param>
        /// <param name="asUeSer"></param>
        /// <returns></returns>
        public static bool SetRegistryValue(RegPath valueLocation, object content, RegistryValueKind registryValueKind,
            bool asUeSer = false)
        {
            if (asUeSer)
            {
                string value;
                switch (registryValueKind)
                {
                    case RegistryValueKind.DWord:
                        value = ((uint) content).ToString();
                        break;
                    case RegistryValueKind.QWord:
                        value = ((ulong) content).ToString();
                        break;
                    case RegistryValueKind.String:
                        value = ((string) content).Replace("\"", "\"\"");
                        break;
                    case RegistryValueKind.MultiString:
                        value = string.Join("\0", (string[]) content).Replace("\"", "\"\"");
                        break;
                    case RegistryValueKind.ExpandString:
                        value = ((string) content).Replace("\"", "\"\"");
                        break;
                    default:
                        value = (string) content;
                        break;
                }

                string kind = RegistryValueKind.String.ToString();
                if (!Executeexecuteable(Environment.ExpandEnvironmentVariables(@"%windir%\System32\reg.exe"),
                        " add \"" + valueLocation.RegistryKey + "\" /v \"" + valueLocation.ValueName + "\" /t " + kind +
                        " /d \"" + value + "\"", out string[] ret, out int tmpExitCode, true, true, true, false,
                        true) || tmpExitCode == 1)
                {
                }

                return true;
            }

            try
            {
                Registry.SetValue(valueLocation.ValueName, valueLocation.ValueName, content, registryValueKind);
            }
            catch (SecurityException)
            {
                if (MessageBox.Show(
                        "Fehler beim setzen des Registry Wertes\"" + valueLocation.ValueName + "\", welcher unter \"" +
                        valueLocation.ValueName + "\" gespeichert ist, auf den wert\"" + content + "\" mit dem Typ \"" +
                        registryValueKind + "\"ist ein Fehler aufgetreten, da dieser Wert schreibgeschützt ist",
                        "Fehler", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error) == DialogResult.Retry)
                {
                    return SetRegistryValue(valueLocation, content, registryValueKind);
                }

                return false;
            }
            catch (UnauthorizedAccessException)
            {
                if (MessageBox.Show(
                        "Fehler beim setzen des Registry Wertes\"" + valueLocation.ValueName + "\", welcher unter \"" +
                        valueLocation.ValueName + "\" gespeichert ist, auf den wert\"" + content + "\" mit dem Typ \"" +
                        registryValueKind +
                        "\"ist ein Fehler aufgetreten, da dieses Programm aktuell nicht die nötigen Berechtigungen besitzt um diese operation durchzuführen." +
                        " Wollen sie die Anwendung mit Administratoren-Privilegien neustarten?", "Fehler",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.Yes)
                {
                    RestartAsAdministrator();
                    return true;
                }

                return false;
            }
            catch (Exception)
            {
                if (MessageBox.Show(
                        "Fehler beim setzen des Registry Wertes\"" + valueLocation.ValueName + "\", welcher unter \"" +
                        valueLocation.ValueName + "\" gespeichert ist, auf den wert\"" + content + "\" mit dem Typ \"" +
                        registryValueKind + "\"ist ein Fehler aufgetreten", "Fehler", MessageBoxButtons.RetryCancel,
                        MessageBoxIcon.Error) == DialogResult.Retry)
                {
                    return SetRegistryValue(valueLocation, content, registryValueKind);
                }

                return false;
            }

            return true;
        }

        #region From https://stackoverflow.com/a/26473940/6730162 access on 30.9.2017

        /// <summary>
        ///     Tests whether a File is a symlink
        /// </summary>
        /// <param name="path">The path of the file to test</param>
        /// <returns>Whether the file is a symlink</returns>
        public static bool IsPathSymbolic(string path)
        {
            FileInfo pathInfo = new FileInfo(path);
            return pathInfo.Attributes.HasFlag(FileAttributes.ReparsePoint);
        }

        #endregion

        #region From https://stackoverflow.com/a/38308957/6730162 access on 30.9.2017

        [DllImport("kernel32.dll", EntryPoint = "CreateFileW", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFile(string lpFileName, int dwDesiredAccess, int dwShareMode,
            IntPtr SecurityAttributes, int dwCreationDisposition, int dwFlagsAndAttributes, IntPtr hTemplateFile);

        [DllImport("kernel32.dll", EntryPoint = "GetFinalPathNameByHandleW", CharSet = CharSet.Unicode,
            SetLastError = true)]
        private static extern int GetFinalPathNameByHandle([In] IntPtr hFile, [Out] StringBuilder lpszFilePath,
            [In] int cchFilePath, [In] int dwFlags);

        private const int CREATION_DISPOSITION_OPEN_EXISTING = 3;
        private const int FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;

        /// <summary>
        ///     Reads the TargetPath stored in the a symlink
        /// </summary>
        /// <param name="path">The path of the symlink</param>
        /// <returns>The path stored in the symlink</returns>
        public static string GetRealPath(string path)
        {
            if (!Directory.Exists(path) && !File.Exists(path))
            {
                throw new IOException("TargetPath not found");
            }

            DirectoryInfo symlink = new DirectoryInfo(path); // No matter if it's a file or folder
            SafeFileHandle directoryHandle = CreateFile(symlink.FullName, 0, 2, IntPtr.Zero,
                CREATION_DISPOSITION_OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, IntPtr.Zero); //Handle file / folder
            if (directoryHandle.IsInvalid)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            StringBuilder result = new StringBuilder(512);
            int mResult = GetFinalPathNameByHandle(directoryHandle.DangerousGetHandle(), result, result.Capacity, 0);
            if (mResult < 0)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            if (result.Length >= 4 && result[0] == '\\' && result[1] == '\\' && result[2] == '?' && result[3] == '\\')
            {
                return result.ToString().Substring(4); // "\\?\" remove
            }

            return result.ToString();
        }

        #endregion

        #region From https://stackoverflow.com/a/3774508/6730162 access on 02.10.2017

        /// <summary>
        ///     Checks whether a user is Part of a localgroup
        /// </summary>
        /// <param name="username">The Name of the User to search for</param>
        /// <param name="localGroup">The localgroup to search in</param>
        /// <returns>Whether the user is in the logalgroup</returns>
        public static bool IsUserInLocalGroup(string username, string localGroup)
        {
            GroupPrincipal oGroupPrincipal = GetGroup(localGroup);
            PrincipalSearchResult<Principal> oPrincipalSearchResult = oGroupPrincipal.GetMembers();
            return oPrincipalSearchResult.Any(principal => principal.Name == username);
        }

        private static GroupPrincipal GetGroup(string sGroupName)
        {
            PrincipalContext oPrincipalContext = GetPrincipalContext();
            GroupPrincipal oGroupPrincipal = GroupPrincipal.FindByIdentity(oPrincipalContext, sGroupName);
            return oGroupPrincipal;
        }

        private static PrincipalContext GetPrincipalContext()
        {
            PrincipalContext oPrincipalContext = new PrincipalContext(ContextType.Machine);
            return oPrincipalContext;
        }

        #endregion

        /// <summary>
        ///     Runs a given Action for each Element of an IEnumerable
        /// </summary>
        /// <param name="Base">The IEnumerable to perform Actions with</param>
        /// <param name="action">The Action to perform with each Element of the Base</param>
        /// <typeparam name="T">The Type of the IEnumerable</typeparam>
        public static void ForEach<T>(this IEnumerable<T> Base, Action<T> action)
        {
            foreach (T variable in Base)
            {
                action(variable);
            }
        }

        /// <summary>
        ///     Restarts Program as Administartor
        /// </summary>
        public static void RestartAsAdministrator()
        {
            if (Executeexecuteable(Process.GetCurrentProcess().MainModule.FileName, "", true, false, false))
            {
                Environment.Exit(0);
            }
        }
    }
}