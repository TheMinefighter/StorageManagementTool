﻿using System.Linq;

namespace StorageManagementTool
{
    public class UserShellFolder
    {
        public UserShellFolder(string Name, RegPath[] Regpaths)
        {
            this.ViewedName = Name;
            this.RegPaths = Regpaths;
        }

        public UserShellFolder(string name, string id)
        {
            this.ViewedName = name;
            this.RegPaths = new[] { new RegPath(ShellFolderRoot, id), new RegPath(UserShellFolderRoot, id) }
            ;
        }
        public string ViewedName { get; set; }
        public RegPath[] RegPaths { get; set; }

        public const string UserShellFolderRoot = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders";
        public const string ShellFolderRoot =
            @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders";

        #region Basierend auf https://support.microsoft.com/en-us/help/931087/how-to-redirect-user-shell-folders-to-a-specified-path-by-using-profil

        public static readonly UserShellFolder[] AllEditableUserUserShellFolders =
        {
            new UserShellFolder("Eigene Dokumente", "Personal"),
            new UserShellFolder("Eigene Musik", "My Music"),
            new UserShellFolder("Eigene Bilder", "My Pictures"),
            new UserShellFolder("Senden an", "SendTo"),
            new UserShellFolder("Anwendungsdaten\\Local", "Local AppData"),
            new UserShellFolder("Anwendungsdaten\\Roaming", "AppData"),
            new UserShellFolder("Startmenü Inhalt", "Programs"),
            new UserShellFolder("Startmenü", "Start Menu"),
            new UserShellFolder("Autostart", "Startup"),
            new UserShellFolder("Verlauf", "History"),
            new UserShellFolder("Favoriten", "Favorites"),
        };

        #endregion
        public static UserShellFolder GetUSFByName(string name)
        {
            return AllEditableUserUserShellFolders.FirstOrDefault(x => x.ViewedName == name);
        }
    }
}
